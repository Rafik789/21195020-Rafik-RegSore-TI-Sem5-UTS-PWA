/*!
* Start Bootstrap - Personal v1.0.1 (https://startbootstrap.com/template-overviews/personal)
* Copyright 2013-2023 Start Bootstrap
* Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-personal/blob/master/LICENSE)
*/
// This file is intentionally blank
// Use this file to add JavaScript to your project
// Membuat atau membuka database IndexedDB
var request = indexedDB.open("CRUD_DB", 1);
var db;

request.onupgradeneeded = function(event) {
    db = event.target.result;
    var objectStore = db.createObjectStore("data", { keyPath: "nim" });
    objectStore.createIndex("nama", "nama", { unique: false });
};

request.onsuccess = function(event) {
    db = event.target.result;
};

request.onerror = function(event) {
    console.log("Error opening IndexedDB");
};

// Fungsi untuk menambahkan data ke IndexedDB
function addDataToDB(data) {
    var transaction = db.transaction(["data"], "readwrite");
    var objectStore = transaction.objectStore("data");
    var request = objectStore.add(data);

    request.onsuccess = function(event) {
        console.log("Data added to IndexedDB");
    };

    request.onerror = function(event) {
        console.log("Error adding data to IndexedDB");
    };
}

// Fungsi untuk menampilkan data dari IndexedDB
function displayDataFromDB() {
    var transaction = db.transaction(["data"], "readonly");
    var objectStore = transaction.objectStore("data");
    var request = objectStore.openCursor();

    var commentsList = document.getElementById("comments-list");
    commentsList.innerHTML = '';

    request.onsuccess = function(event) {
        var cursor = event.target.result;
        if (cursor) {
            var listItem = document.createElement("li");
            listItem.appendChild(document.createTextNode("Nama: " + cursor.value.nama + ", NIM: " + cursor.value.nim));
            commentsList.appendChild(listItem);
            cursor.continue();
        }
    };
}

// Menangani submit form
document.getElementById("crud-form").addEventListener("submit", function(event) { event.preventDefault();
    
    var formData = {
        nama: document.getElementById("nama").value,
        nim: document.getElementById("nim").value,
        kelas: document.getElementById("kelas").value,
        semester: document.getElementById("semester").value,
        mataKuliah: document.getElementById("mata-kuliah").value,
        tujuan: document.getElementById("tujuan").value
    };

    addDataToDB(formData);
    displayDataFromDB();

    document.getElementById("crud-form").reset();
});
